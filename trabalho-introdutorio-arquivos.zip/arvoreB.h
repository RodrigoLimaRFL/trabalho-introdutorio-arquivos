/*#ifndef ARVOREB_H
    #define ARVOREB_H

    #include "registroArvoreB.h"
    #include "cabecalhoArvoreB.h"

    void inserirArvoreB(FILE *arquivo, int chave, long long int byteOffset);
    void imprimirArvoreBGraphviz(FILE *arquivo);
#endif*/