#ifndef INTERPRETA_BIN_H
    #define INTERPRETA_BIN_H
    #include "registro.h"
    #include "cabecalho.h"

    CABECALHO *getCabecalhoFromBin(FILE *file);
    //LISTA *getRegistrosFromBin(char *filePath);
#endif