#ifndef CRIAR_INDICE_H
    #define CRIAR_INDICE_H

    #include <stdio.h>
    #include <stdlib.h>

    #include "indice.h"
    #include "lista.h"
    #include "cabecalho.h"
    #include "registroIndice.h"
    #include "interpreta-bin.h"

    void lerBinCriarIndice(char *arquivoBin, char *arquivoIndice);
#endif