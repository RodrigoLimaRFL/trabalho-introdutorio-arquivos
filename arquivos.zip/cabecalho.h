#ifndef CABECALHO_H

  #define CABECALHO_H

  #include "lista.h"

  typedef struct cabecalho_ CABECALHO;

  CABECALHO *criarCabecalho(void);

  void setValoresCabecalho(CABECALHO *cabecalho, LISTA *lista);

  char getStatus(CABECALHO *cabecalho);

  long getTopo(CABECALHO *cabecalho);

  long getProxByteOffset(CABECALHO *cabecalho);

  int getNroRegArq(CABECALHO *cabecalho);

  int getNroRem(CABECALHO *cabecalho);

  void setStatus(CABECALHO *cabecalho, char status);

  void setTopo(CABECALHO *cabecalho, long topo);

  void setProxByteOffset(CABECALHO *cabecalho, double proxByteOffset);

  void setNroRegArq(CABECALHO *cabecalho, int nroRegArq);

  void setNroRem(CABECALHO *cabecalho, int nroRem);

  void apagarCabecalho(CABECALHO *cabecalho);

#endif