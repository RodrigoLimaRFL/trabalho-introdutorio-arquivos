#include "lista.h"
#include "registro.h"
#include "cabecalho.h"

CABECALHO *getCabecalhoFromBin(char *filePath);
LISTA *getRegistrosFromBin(char *filePath);