#include <stdio.h>

#include "gerencia-arquivo.h"
#include "lista.h"
#include "interpreta-bin.h"
#include "cabecalho.h"

int main() {
    int comando;

    scanf("%d", &comando);

    switch (comando) {
        case 1:
            // Ler CSV e Escrever Binário
            CABECALHO *cabecalho = criarCabecalho();
            LISTA *lista = lerCsv("Jogador.csv");
            escreveBinario(cabecalho, lista, "bin");
            break;
        case 2:
            // Ler Binario
            break;
        case 3:
            // Busca
        default:
            break;
    }

    CABECALHO *cabecalho = criarCabecalho();
    LISTA *lista = lerCsv("Jogador.csv");
    escreveBinario(cabecalho, lista, "bin");
    // cabecalho = getCabecalhoFromBin("bin");
    // LISTA *lista2 = getRegistrosFromBin("bin");
    BuscaNacionalidadeEIdade(lista, "FRANCE", 24);
    //teste();
    return 0;
}